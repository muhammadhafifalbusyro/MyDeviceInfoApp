import { NotchDevice } from './privateTypes';
declare const devicesWithNotch: NotchDevice[];
export default devicesWithNotch;
