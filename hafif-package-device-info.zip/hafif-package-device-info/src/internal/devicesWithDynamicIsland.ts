import { NotchDevice } from 'hafif-package-device-info/src/internal/privateTypes';

const devicesWithDynamicIsland: NotchDevice[] = [
  {
    brand: 'Apple',
    model: 'iPhone 14 Pro',
  },
  {
    brand: 'Apple',
    model: 'iPhone 14 Pro Max',
  },
];

export default devicesWithDynamicIsland;
